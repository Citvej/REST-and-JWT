﻿namespace Rain51
{
    public class Student
    {
    }
}